CREATE DATABASE  IF NOT EXISTS `guida` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `guida`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: guida
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `idlocation` varchar(2) NOT NULL,
  `Busy` tinyint(1) NOT NULL,
  `Price` int NOT NULL,
  `Disabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`idlocation`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES ('1A',0,10,0),('1B',0,8,0),('1C',0,6,0),('2A',0,10,0),('2B',0,8,0),('2C',0,6,0),('3A',0,10,0),('3B',0,8,0),('3C',0,6,0),('4A',0,10,0),('4B',0,8,0),('4C',0,6,0),('5A',0,10,0),('5B',0,8,0),('5C',0,6,0),('6A',0,10,0),('6B',0,8,0),('6C',0,6,0),('7A',0,10,0),('7B',0,8,0),('7C',0,6,0),('8A',0,10,0),('8B',0,8,0),('8C',0,6,0);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `order_id` varchar(100) NOT NULL,
  `user_id` int NOT NULL,
  `Instruction` varchar(100) DEFAULT NULL,
  `OrderPay` tinyint(1) NOT NULL,
  `Total` int NOT NULL,
  `Delivered` tinyint(1) NOT NULL,
  `Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`order_id`),
  KEY `fk_order_user1_idx` (`user_id`),
  CONSTRAINT `fk_order_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES ('order_8304096170',5,'Forte intolleranza all\'aglio',1,12,1,'2020-09-07 10:52:14');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_product`
--

DROP TABLE IF EXISTS `order_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_product` (
  `product_Code` int NOT NULL,
  `order_order_id` varchar(100) NOT NULL,
  `Quantity` varchar(100) NOT NULL,
  PRIMARY KEY (`product_Code`,`order_order_id`),
  KEY `fk_product_has_order_order1_idx` (`order_order_id`),
  KEY `fk_product_has_order_product1_idx` (`product_Code`),
  CONSTRAINT `fk_product_has_order_order1` FOREIGN KEY (`order_order_id`) REFERENCES `order` (`order_id`),
  CONSTRAINT `fk_product_has_order_product1` FOREIGN KEY (`product_Code`) REFERENCES `product` (`Code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_product`
--

LOCK TABLES `order_product` WRITE;
/*!40000 ALTER TABLE `order_product` DISABLE KEYS */;
INSERT INTO `order_product` VALUES (2,'order_8304096170','1'),(3,'order_8304096170','1'),(17,'order_8304096170','1');
/*!40000 ALTER TABLE `order_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prenotation`
--

DROP TABLE IF EXISTS `prenotation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prenotation` (
  `idPrenotation` varchar(100) NOT NULL,
  `user_id` int NOT NULL,
  `location_idlocation` varchar(2) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Out` tinyint(1) NOT NULL DEFAULT '0',
  KEY `fk_prenotation_user1_idx` (`user_id`),
  KEY `fk_prenotation_location1_idx` (`location_idlocation`),
  CONSTRAINT `fk_prenotation_location1` FOREIGN KEY (`location_idlocation`) REFERENCES `location` (`idlocation`),
  CONSTRAINT `fk_prenotation_user1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prenotation`
--

LOCK TABLES `prenotation` WRITE;
/*!40000 ALTER TABLE `prenotation` DISABLE KEYS */;
INSERT INTO `prenotation` VALUES ('LIDOPRID1868404732-1174050840',5,'2B','2020-09-07 10:50:36',1),('LIDOPRID1868404732-1174050840',5,'7C','2020-09-07 10:50:36',1),('LIDOPRID18684047322124656371',5,'6B','2020-09-07 10:51:07',1),('LIDOPRID18684047322124656371',5,'4A','2020-09-07 10:51:07',1),('LIDOPRID18684047322124656371',5,'2C','2020-09-07 10:51:07',1),('LIDOPRID18684047322124656371',5,'8B','2020-09-07 10:51:07',1);
/*!40000 ALTER TABLE `prenotation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `Code` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  `Description` varchar(45) NOT NULL,
  `Price` double NOT NULL,
  `Category` varchar(45) NOT NULL,
  `imgURL` varchar(100) NOT NULL,
  PRIMARY KEY (`Code`),
  UNIQUE KEY `Code_UNIQUE` (`Code`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Bruschette','Pane a fette,Pomodoro,Basilico',4,'Antipasto','http://localhost:8080/guidafederico/imageRestaurant/bruschette.jpg'),(2,'Patate Fritte','Piatto di patatine fritte',3,'Antipasto','http://localhost:8080/guidafederico/imageRestaurant/patatefritte.jpg'),(3,'Pepata cozze','Cozze, Pepe nero e Limone',7,'Antipasto','http://localhost:8080/guidafederico/imageRestaurant/impcozze.jpg'),(4,'Insalata di mare','Gamberi,Cozze,Seppie,Polpo,Pepe',10,'Antipasto','http://localhost:8080/guidafederico/imageRestaurant/insmare.jpg'),(5,'Pasta alla norma','Passata,Melanzane e Basilico',7,'Primi','http://localhost:8080/guidafederico/imageRestaurant/pastanorma.jpg'),(6,'Risotto ai funghi porcini','Funghi Porcini, Peperoncino, Panna',11,'Primi','http://localhost:8080/guidafederico/imageRestaurant/risottofun.jpg'),(7,'Ravioli cernia','Aglio, Burro, Scampi, Gambero',15,'Primi','http://localhost:8080/guidafederico/imageRestaurant/ravcernia.jpg'),(8,'Spaghetti Vongole','Vongole, Peperoncino, Vino Bianco',12,'Primi','http://localhost:8080/guidafederico/imageRestaurant/spavon.jpg'),(12,'Trittico di mare','Calamari, Pesce spada, Gamberoni',18,'Secondo','http://localhost:8080/guidafederico/imageRestaurant/trittico.jpg'),(13,'Filetto di Vitello Al Pepe Verde','Fondo Bruno, Panna e Pepe Verde',12,'Secondo','http://localhost:8080/guidafederico/imageRestaurant/filetto.jpeg'),(14,'Bistecca di Vitello Alla Palermitana','Aglio, Olio, Pepe, Pangrattato',10,'Secondo','http://localhost:8080/guidafederico/imageRestaurant/bistecca.jpg'),(15,'Millefoglie Vegetariana','Patate, Salmone, Rucola',10,'Secondo','http://localhost:8080/guidafederico/imageRestaurant/millefoglie.jpg'),(16,'Acqua Minerale','1 Litro',2,'Bibita','http://localhost:8080/guidafederico/imageRestaurant/acqua.jpg'),(17,'Coca cola','1 Litro',2,'Bibita','http://localhost:8080/guidafederico/imageRestaurant/cocacola.jpg'),(18,'Aperitivo spritz','Aperol , Soda, Prosecco',5,'Bibita','http://localhost:8080/guidafederico/imageRestaurant/spritz.jpg'),(19,'Birra Heineken','cl. 0,33',2,'Bibita','http://localhost:8080/guidafederico/imageRestaurant/heineken.jpg');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Email` varchar(255) NOT NULL,
  `Name` varchar(16) NOT NULL,
  `Surname` varchar(16) NOT NULL,
  `Age` int NOT NULL,
  `Password` varchar(32) NOT NULL,
  `Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `Role` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin@gmail.com','Admin','Admin',25,'admin','2020-09-03 19:20:19','admin'),(2,'cashier@gmail.com','Cashier','Cashier',25,'cashier','2020-09-03 19:20:19','cashier'),(3,'receptionist@gmail.com','Receptionist','Receptionist',25,'receptionist','2020-09-03 19:20:19','receptionist'),(4,'cook@gmail.com','Cook','Cook',25,'cook','2020-09-03 19:20:19','cook'),(5,'user@gmail.com','User','User',25,'user','2020-09-03 19:20:19','user');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-07 12:57:16
